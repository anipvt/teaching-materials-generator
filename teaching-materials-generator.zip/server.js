require('dotenv').config();
const express = require('express');
const cors = require('cors');
const axios = require('axios');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Azure OpenAI API credentials
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const OPENAI_API_ENDPOINT = process.env.OPENAI_API_ENDPOINT;

// API route to generate teaching materials
app.post('/api/generate', async (req, res) => {
  try {
    const { semester, subject, classNumber, topic, difficultyLevel } = req.body;
    
    // Validate input
    if (!semester || !subject || !classNumber || !topic || !difficultyLevel) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    // Create prompt for OpenAI
    const prompt = `
      Create comprehensive teaching materials for the following:
      
      Semester: ${semester}
      Subject: ${subject}
      Class: ${classNumber}
      Topic: ${topic}
      Difficulty Level: ${difficultyLevel}
      
      Please provide the following in your response:
      
      Step 1: 
      - Break the topic "${topic}" into sub-topics to teach
      - Suggest a lecture title
      - Create a basic editable summary
      
      Step 2:
      - Create class lecture materials:
        - PPT slides (basic outline of what should be included)
        - Reference links (articles, YouTube videos, research papers)
        - Interactive quiz & polls (with QR codes)
        - Case studies
        - Enable downloads (ppt, quiz pdfs, etc.)
    `;

    // Call Azure OpenAI API
    const response = await axios.post(
      OPENAI_API_ENDPOINT,
      {
        messages: [
          { role: "system", content: "You are an expert educational content creator specialized in creating comprehensive teaching materials." },
          { role: "user", content: prompt }
        ],
        max_tokens: 2500,
        temperature: 0.7
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'api-key': OPENAI_API_KEY
        }
      }
    );

    // Extract the content from OpenAI response
    const generatedContent = response.data.choices[0].message.content;

    // Return the generated content
    res.json({ result: generatedContent });
  } catch (error) {
    console.error('Error calling OpenAI API:', error.response?.data || error.message);
    res.status(500).json({ 
      error: 'Failed to generate content', 
      details: error.response?.data?.error?.message || error.message 
    });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
